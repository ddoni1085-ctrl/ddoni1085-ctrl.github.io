<?php
require __DIR__ . '/functions.php';
$code = strtoupper(trim((string)($_GET['code'] ?? '')));
$voter = preg_match('/^[A-F0-9]{24}$/', $code) ? voter_by_code($code) : null;
header_html('Surat Suara Digital');
if (!$voter): ?>
<div class="center-panel"><h1>QR tidak ditemukan</h1><p>Periksa kembali QR atau minta panitia membuat QR yang benar.</p><a class="btn" href="scan.php">Pindai Ulang</a></div>
<?php elseif ($voter['used']): ?>
<div class="center-panel"><h1>QR sudah digunakan</h1><p>Atas nama <b><?=e($voter['name'])?></b> sudah tercatat mengikuti simulasi.</p><a class="btn" href="hasil.php">Lihat Hasil</a></div>
<?php else: ?>
<div class="ballot-head"><div class="eyebrow">SURAT SUARA DIGITAL — SIMULASI</div><h1>Pemilihan Kepala Desa</h1><p><?=e(APP_VILLAGE)?></p><div class="voter-name">Pemilih: <b><?=e($voter['name'])?></b></div></div>
<p class="instruction">Silakan pilih salah satu foto calon kepala desa.</p>
<div class="candidate-grid">
<?php foreach (CANDIDATES as $id => $c): ?>
<button class="candidate" data-id="<?=$id?>" data-name="<?=e($c['name'])?>" data-photo="<?=e($c['photo'])?>" type="button"><span class="number"><?=$id?></span><img src="<?=e($c['photo'])?>" alt="Foto <?=e($c['name'])?>"><b><?=e($c['name'])?></b></button>
<?php endforeach; ?>
</div>
<div class="banner">Pilih satu kandidat untuk melanjutkan</div>
<div class="modal-backdrop" id="modal" hidden><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><h2 id="modal-title">Konfirmasi Pilihan</h2><p>Apakah Anda yakin akan memilih kandidat ini?</p><img id="chosen-photo" alt="Foto calon terpilih"><strong id="chosen-name"></strong><form action="proses_suara.php" method="post" class="modal-actions"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="code" value="<?=e($code)?>"><input type="hidden" name="candidate_id" id="candidate-id"><button class="btn secondary" type="button" id="cancel">Ulangi</button><button class="btn" type="submit">Ya, Pilih</button></form></div></div>
<script>
const modal=document.getElementById('modal');
document.querySelectorAll('.candidate').forEach(b=>b.addEventListener('click',()=>{
 document.getElementById('chosen-photo').src=b.dataset.photo;
 document.getElementById('chosen-name').textContent=b.dataset.name;
 document.getElementById('candidate-id').value=b.dataset.id;
 modal.hidden=false;
}));
document.getElementById('cancel').onclick=()=>{modal.hidden=true};
modal.addEventListener('click',e=>{if(e.target===modal)modal.hidden=true;});
document.addEventListener('keydown',e=>{if(e.key==='Escape')modal.hidden=true;});
</script>
<?php endif; footer_html(); ?>
