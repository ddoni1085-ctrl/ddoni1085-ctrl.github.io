<?php
declare(strict_types=1);
const APP_TITLE = 'Simulasi Pemilihan Kepala Desa Digital';
const APP_VILLAGE = 'Desa Contoh';
const STORE_PATH = __DIR__ . '/data/state.json';
const CANDIDATES = [
    1 => ['name' => 'Ikmal Wawan', 'photo' => 'assets/img/calon1.jpg'],
    2 => ['name' => 'Lulu Lukman', 'photo' => 'assets/img/calon2.jpg'],
    3 => ['name' => 'Yosep Rohayadi', 'photo' => 'assets/img/calon3.jpg'],
    4 => ['name' => 'Zainal Aripin', 'photo' => 'assets/img/calon4.jpg'],
    5 => ['name' => 'Muhammad Zainal Aripin S.H.', 'photo' => 'assets/img/calon5.jpg'],
];
